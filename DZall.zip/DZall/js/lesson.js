// PHONE CHECKER

const card = document.querySelector('.card'),
    btnPrev = document.querySelector('#btn-prev'),
    btnNext = document.querySelector('#btn-next')

let count = 0

btnNext.addEventListener('click', () => {
    if (count < 2) {
        count++
        cardSwitcherReq(count)
    } else {
        count = 0
        cardSwitcherReq(count)
    }
})

btnPrev.addEventListener('click', () => {
    if (count > 0) {
        count--
        cardSwitcherReq(count)
    } else {
        count = 2
        cardSwitcherReq(count)
    }
})

const cardSwitcherReq = async (count) => {
    try {
        const response = await fetch(`../data/characters.json/`)
        const data = await response.json()

        if (!response.ok) return null

        card.innerHTML = `
                <p>Name: ${data[count].name}</p>
                <p>Age: ${data[count].age}</p>
                <div>   
                    <img src="${data[count].person_photo}" alt="logo" width="60px" height="60px">
                </div>
            `
    } catch (e) {
        console.log(e)
    }
}

cardSwitcherReq(count)


// get any data

const fetchAnyData = async () => {
    try {
        const response = await fetch(`../data/any.json/`)
        const anyData = await response.json()

        if (!response.ok) return null

        anyData.forEach((item, index) => {
            console.log('========== person ' + (index + 1) + " =============")
            console.log('name: ', item.name)
            console.log('age: ', item.age)
            console.log('hobby: ', item.subtitle)
            console.log('job: ', item.job)
        })

    } catch (e) {
        console.log(e)
    }
}

fetchAnyData()